# -*- coding: utf-8 -*-

##
## Asignatura: Gestión de la Información en la Web (GIW)
## Práctica: MongoEngine
## Grupo: 9
## Autores: Ahsin Rashid, Javier Garrido Montes, Lorena Jiménez Corta y Gonzalo Jiménez Corta
##
## Ahsin Rashid, Javier Garrido Montes, Lorena Jiménez Corta y Gonzalo Jiménez Corta declaramos que esta solución es fruto exclusivamente
## de nuestro trabajo personal. No hemos sido ayudados por ninguna otra persona ni hemos
## obtenido la solución de fuentes externas, y tampoco hemos compartido nuestra solución
## con nadie. Declaramos además que no hemos realizado de manera deshonesta ninguna otra
## actividad que pueda mejorar nuestros resultados ni perjudicar los resultados de los demás.
##

from mongoengine import *
from datetime import datetime

class TarjetaCredito(EmbeddedDocument):
	nombre_propietario = StringField(required = True)
	numero = StringField(required = True, regex = "^\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d\d$")
	mes_caducidad = StringField(required = True, regex = "^\d\d$")
	anio_caducidad = StringField(required = True, regex = "^\d\d$")
	cvv = StringField(required = True, regex = "^\d\d\d$")

class Producto(Document):
	barcode = StringField(primary_key = True, regex = "^\d\d\d\d\d\d\d\d\d\d\d\d\d$")
	nombre = StringField(required = True)
	categoria_principal = IntField(required = True, min_value = 0)
	categorias_secundarias = ListField(IntField(min_value = 0), required = False)

	def clean(self):
		## APARTADO 5 : Validar código de barras
		# Calcular checksum
		checksum = 0
		for i in range(12, 0, -2):
			checksum += int(self.barcode[i]) + 3 * int(self.barcode[i - 1])
		# Calcular checkdigit
		checkdigit = 10 - (checksum % 10)
		# Comprobar que el dígito de control del código de barras sea correcto (igual a checkdigit)
		if checkdigit != int(self.barcode[0]):
			raise ValidationError("El dígito de control del código de barras no es válido")

		## APARTADO 6 : Validar que la primera categoría secundaria (en caso de haberla) sea igual a la categoría principal
		if self.categorias_secundarias != [] and self.categorias_secundarias[0] != self.categoria_principal:
			raise ValidationError("La lista de categorías secundarias no es válida porque su primer elemento no es la categoría principal")

class LineaPedido(EmbeddedDocument):
	cantidad_productos = IntField(required = True, min_value = 1)
	precio_producto = FloatField(required = True, min_value = 0)
	nombre_producto = StringField(required = True)
	precio_total = FloatField(required = True, min_value = 0)
	producto = ReferenceField(Producto)

	def clean(self):
		## APARTADO 3 : Validar precio total en base al precio y la cantidad del producto
		if self.cantidad_productos * self.precio_producto != self.precio_total:
			raise ValidationError("El precio total de la línea de pedido no está correctamente calculado en base al precio y la cantidad del producto")

		## APARTADO 4 : Validar nombre del producto
		if self.nombre_producto != self.producto.nombre:
			raise ValidationError("El nombre del producto de la línea de pedido no es el mismo que el del producto al que apunta la referencia")

class Pedido(Document):
	precio_total = FloatField(required = True, min_value = 0)
	fecha = ComplexDateTimeField(required = True)
	lineas = ListField(EmbeddedDocumentField(LineaPedido, required = True))

	def clean(self):
		## APARTADO 2 : Validar precio total
		precio_total = 0
		for linea in self.lineas:
			precio_total += linea.precio_total
		if round(precio_total, 2) != self.precio_total:
			raise ValidationError("El precio total del pedido no es exactamente la suma de los precios de todas sus líneas")

class Usuario(Document):
	dni = StringField(primary_key = True, regex = "^\d\d\d\d\d\d\d\d[A-z]$")
	nombre = StringField(required = True)
	primer_apellido = StringField(required = True)
	segundo_apellido = StringField(required = False)
	fecha_nacimiento = StringField(required = True, regex = "^\d\d\d\d-\d\d-\d\d$")
	fecha_ultimos_10_accesos = ListField(ComplexDateTimeField(), required = False)
	lista_tarjetas_credito = ListField(EmbeddedDocumentField(TarjetaCredito), required = False)
	lista_referencias_pedidos = ListField(ReferenceField(Pedido, reverse_delete_rule = 4), required = False)
	
	def clean(self):
		## APARTADO 1 : Validar DNI
		tabla = ['T','R','W','A','G','M','Y','F','P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E']
		num_dni = int(self.dni[0:8])
		letra = tabla[num_dni % 23]
		if letra != self.dni[-1].upper():
			raise ValidationError("El DNI no es válido porque su letra no se corresponde con su número")

		## Validar fecha de nacimiento
		# Comprobar día
		dia = int(self.fecha_nacimiento.split("-")[2])
		if dia < 0 or dia > 31:
			raise ValidationError("El día de la fecha de nacimiento es incorrecto. Debe ser positivo y menor o igual que 31")
		# Comprobar mes
		mes = int(self.fecha_nacimiento.split("-")[1])
		if mes < 0 or mes > 12:
			raise ValidationError("El mes de la fecha de nacimiento es incorrecto. Debe ser positivo y menor o igual que 12")

		## Validar que los últimos 10 accesos sean una lista de no más de 10 posiciones
		if len(self.fecha_ultimos_10_accesos) > 10:
			raise ValidationError("Sólo se puede introducir como máximo 10 últimas fechas de acceso")
	
def insertar():
	## CREAR TARJETA 1
	tarjeta1 = TarjetaCredito()
	tarjeta1.nombre_propietario = "Gonzalo Jiménez Corta"
	tarjeta1.numero = "1234123412341234"
	tarjeta1.mes_caducidad = "04"
	tarjeta1.anio_caducidad = "30"
	tarjeta1.cvv = "123"

	## CREAR TARJETA 2
	tarjeta2 = TarjetaCredito()
	tarjeta2.nombre_propietario = "Lorena Jiménez Corta"
	tarjeta2.numero = "9876987698769876"
	tarjeta2.mes_caducidad = "11"
	tarjeta2.anio_caducidad = "19"
	tarjeta2.cvv = "987"

	## CREAR PRODUCTO 1 E INSERTARLO EN LA BD
	producto1 = Producto()
	producto1.barcode = "5426973102087"
	producto1.nombre = "Manzana"
	producto1.categoria_principal = 1
	producto1.categorias_secundarias = [1,2,3]
	producto1.save()

	## CREAR PRODUCTO 2 E INSERTARLO EN LA BD
	producto2 = Producto()
	producto2.barcode = "9000000000001"
	producto2.nombre = "Pera"
	producto2.categoria_principal = 3
	producto2.save()

	## CREAR PRODUCTO 3 E INSERTARLO EN LA BD
	producto3 = Producto()
	producto3.barcode = "7000000000010"
	producto3.nombre = "Melocotón"
	producto3.categoria_principal = 4
	producto3.categorias_secundarias = [4,2]
	producto3.save()

	## CREAR LINEA DE PEDIDO 1
	linea1 = LineaPedido()
	linea1.cantidad_productos = 4
	linea1.precio_producto = 0.25
	linea1.nombre_producto = "Pera"
	linea1.precio_total = 1
	linea1.producto = producto2

	## CREAR LINEA DE PEDIDO 2
	linea2 = LineaPedido()
	linea2.cantidad_productos = 12
	linea2.precio_producto = 0.11
	linea2.nombre_producto = "Manzana"
	linea2.precio_total = 1.32
	linea2.producto = producto1

	## CREAR LINEA DE PEDIDO 3
	linea3 = LineaPedido()
	linea3.cantidad_productos = 1
	linea3.precio_producto = 0.32
	linea3.nombre_producto = "Melocotón"
	linea3.precio_total = 0.32
	linea3.producto = producto3

	## CREAR LINEA DE PEDIDO 4
	linea4 = LineaPedido()
	linea4.cantidad_productos = 22
	linea4.precio_producto = 0.32
	linea4.nombre_producto = "Melocotón"
	linea4.precio_total = 7.04
	linea4.producto = producto3

	## CREAR PEDIDO 1 E INSERTARLO EN LA BD
	pedido1 = Pedido()
	pedido1.precio_total = 2.32
	pedido1.fecha = datetime(2018, 11, 10, 10, 2, 58, 123)
	pedido1.lineas = [linea1, linea2]
	pedido1.save()

	## CREAR PEDIDO 2 E INSERTARLO EN LA BD
	pedido2 = Pedido()
	pedido2.precio_total = 8.36
	pedido2.fecha = datetime(2018, 11, 1, 9, 31, 20, 1)
	pedido2.lineas = [linea3, linea4, linea1]
	pedido2.save()

	## CREAR PEDIDO 3 E INSERTARLO EN LA BD
	pedido3 = Pedido()
	pedido3.precio_total = 8.36
	pedido3.fecha = datetime(2018, 11, 7, 12, 3, 3, 30001)
	pedido3.lineas = [linea4, linea2]
	pedido3.save()

	## CREAR PEDIDO 4 E INSERTARLO EN LA BD
	pedido4 = Pedido()
	pedido4.precio_total = 1.32
	pedido4.fecha = datetime(2018, 11, 19, 17, 45, 51, 302428)
	pedido4.lineas = [linea1, linea3]
	pedido4.save()

	## CREAR USUARIO 1 E INSERTARLO EN LA BD
	usuario = Usuario()
	usuario.dni = "51483376S"
	usuario.nombre = "Gonzalo"
	usuario.primer_apellido = "Jiménez"
	usuario.segundo_apellido = "Corta"
	usuario.fecha_nacimiento = "1996-04-23"
	# Introducir 10 últimas fechas de acceso (cada día desde el 12 de noviembre hasta el 21 de noviembre)
	usuario.fecha_ultimos_10_accesos = []
	for i in range(0, 10):
		usuario.fecha_ultimos_10_accesos.append(datetime(2018, 11, i + 12, 13, 33, 56, 123456))
	usuario.lista_tarjetas_credito = [tarjeta1]
	usuario.lista_referencias_pedidos = [pedido1, pedido2]
	usuario.save()

	## CREAR USUARIO 2 E INSERTARLO EN LA BD
	usuario = Usuario()
	usuario.dni ="51483377q"
	usuario.nombre = "Lorena"
	usuario.primer_apellido = "Jiménez"
	usuario.segundo_apellido = "Corta"
	usuario.fecha_nacimiento = "1991-11-01"
	usuario.lista_tarjetas_credito = [tarjeta1, tarjeta2]
	usuario.lista_referencias_pedidos = [pedido3, pedido4]
	usuario.save()

	## Si se ejecutan estas dos líneas, se borrará el segundo pedido del usuario 1 (Gonzalo) y el primer pedido del usuario 2 (Lorena)
	#pedido2.delete()
	#pedido3.delete()

connect("giw_mongoengine")
insertar()